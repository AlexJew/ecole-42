#!/bin/sh
ls *.sh | sed 's/\.sh/$/'
